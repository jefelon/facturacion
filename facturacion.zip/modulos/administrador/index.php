<?php

/**

 */

require('inicio_admin.php');

?>