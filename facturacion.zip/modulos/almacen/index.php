<?php

/**

 */

require('almacen_vista.php');

?>