<?php

/**

 */

require('atributo_vista.php');

?>