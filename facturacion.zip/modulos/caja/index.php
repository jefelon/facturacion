<?php

/**

 */

require('../marca - Copia/marca_vista.php');

?>