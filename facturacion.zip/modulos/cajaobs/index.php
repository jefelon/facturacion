<?php

/**

 */

require('cajaobs_vista.php');

?>