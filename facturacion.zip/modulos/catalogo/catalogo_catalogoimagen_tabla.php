<?php
session_start();
if($_SESSION["autentificado"]!= "SI"){ header("location: ../../index.php"); exit();}
require_once ("../../config/Cado.php");
require_once ("cCatalogo.php");
$oCatalogo = new cCatalogo();
require_once ("../categoria/cCategoria.php");
$oCategoria = new cCategoria();
require_once ("../formatos/formato.php");


$igv_dato=0.18;
//TIPO DE PRECIO
if($_POST['tippre']==1)
{
	$mul1=1;
	$texto_precio='VALOR VENTA';	
}

if($_POST['tippre']==2)
{
	$mul1=1+$igv_dato;
	$texto_precio='PRECIO VENTA';
}
//TIPO DE MONEDA
if($_POST['mon']==1)
{
	$mul2=$_POST['tipcam'];
	$texto_moneda='S/.';	
}

if($_POST['mon']==2)
{
	$mul2=1/$_POST['tipcam'];
	$texto_moneda='US$';
}

if(isset($_POST['pro_cat']) and $_POST['pro_cat']>0)
{
	$dc=$_POST['pro_cat'].'';
	
	$dts2=$oCategoria->mostrar_por_idp($_POST['pro_cat']);
	$num_rows2= mysql_num_rows($dts2);
	if($num_rows2>0){
		while($dt2 = mysql_fetch_array($dts2)){
			
			$dc.=', '.$dt2['tb_categoria_id'];
			
			$dts3=$oCategoria->mostrar_por_idp($dt2['tb_categoria_id']);
			$num_rows3= mysql_num_rows($dts3);
			if($num_rows3>0){
				while($dt3 = mysql_fetch_array($dts3)){
					$dc.=', '.$dt3['tb_categoria_id'];			
				}
			mysql_free_result($dts3);
			}//fin nivel 3
					
		}
	mysql_free_result($dts2);
	}//fin nivel 2

//echo $dc;			
}

$dts1=$oCatalogo->catalogo_compra_filtro($_POST['pro_nom'],$_POST['pro_cod'],$dc,$_POST['pro_mar'],$_POST['pro_est'], $_POST['limit']);

$num_rows= mysql_num_rows($dts1);
?>
<script type="text/javascript">

$('.moneda').autoNumeric({
	aSep: ',',
	aDec: '.',
	//aSign: 'S/. ',
	//pSign: 's',
	vMin: '0.00',
	vMax: '9999.99'
});
$('.porcentaje').autoNumeric({
	aSep: ',',
	aDec: '.',
	//aSign: 'S/. ',
	//pSign: 's',
	vMin: '0.00',
	vMax: '99.99'
});
$('.cantidad').autoNumeric({
	aSep: ',',
	aDec: '.',
	vMin: '1',
	vMax: '99999'
});

function cantidad(act,idf)
{
	var can=($('#txt_cat_can_'+idf).val())*1;
	//var sto=($('#hdd_cat_stouni_'+idf).val())*1;
	var valor=0;
	var sum=1;
	
	if(act=='mas')
	{
		valor=can+sum;
		if(valor<=999)$('#txt_cat_can_'+idf).val(valor);
	}
	
	if(act=='menos')
	{
		valor=can-sum;
		if(valor>=1)$('#txt_cat_can_'+idf).val(valor);
	}
}

$('.btn_agregar').button({
	icons: {
		//primary: "ui-icon-plusthick",
		//secondary:"ui-icon-cart"
	},
	text: true
});

$('.btn_mas').button({
	icons: {
		primary: "ui-icon-plus"
	},
	text: false
});
$('.btn_menos').button({
	icons: {
		primary: "ui-icon-minus"
	},
	text: false
});

$(".btn_mas").css({width: "16px", height: "14px", 'vertical-align':"buttom", padding: "0 0 3px 0" });
$(".btn_menos").css({width: "16px", height: "14px", 'vertical-align':"buttom", padding: "0 0 3px 0" });

$(function() {	
	$("#tabla_producto").tablesorter({
		widgets: ['zebra', 'zebraHover'] ,
		widthFixed: true,
		headers: {
			7: {sorter: false }, 
			8: { sorter: false}
			},
		//sortForce: [[0,0]],
		<?php if($num_rows>0){?>
		sortList: [[1,0]]
		<?php }?>
    });

}); 
</script>

        <table cellspacing="1" id="tabla_producto" class="tablesorter">
            <thead>
                <tr>
                  	<th>CODIGO</th>
                    <th>NOMBRE</th>
                    <th>UNIDAD</th>
                    <th >&nbsp;</th>
                </tr>
            </thead>
			<?php
            if($num_rows>=1){
            ?>
            <tbody>
                <?php
					while($dt1 = mysql_fetch_array($dts1)){
						//precio_unitario_compra
						$precio_unitario_compra=formato_money($dt1['tb_catalogo_preunicom']*$mul1*$mul2);
						
						?>
                        <tr>
                            <td><?php echo $dt1['tb_presentacion_cod']?></td>
                            <td>
							<?php 
							echo $dt1['tb_producto_nom'];
							?></td>
                            <!--<td>
							<?php 
							//echo ''.$dt1['tb_presentacion_nom'].'';
							?></td>-->
                            <td><?php echo $dt1['tb_unidad_abr']?></td>                           
                            <td align="center"><a class="btn_agregar" href="#" onClick="catalogoimagendetalle_reg('insertar','<?php echo $dt1['tb_catalogo_id']?>')">Agregar</a></td>
                        </tr>
                <?php
                	}
                mysql_free_result($dts1);
                ?>
                </tbody>
                <?php
				}
				?>
                <tr class="even">
                  <td colspan="4"><?php echo $num_rows.' registros'?></td>
                </tr>
        </table>
