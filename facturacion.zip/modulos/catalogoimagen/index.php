<?php 

include('catalogoimagen_vista.php');

 ?>