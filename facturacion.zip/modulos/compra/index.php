<?php

/**

 */

require('compra_vista_adm.php');

?>