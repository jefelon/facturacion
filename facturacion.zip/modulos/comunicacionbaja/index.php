<?php
session_start();
require('venta_vista.php');

?>