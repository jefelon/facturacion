<?php

/**

 */

require('./manCuentas.php');

?>