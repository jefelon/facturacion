<?php

/**

 */

require('documento_vista.php');

?>