<?php

/**

 */

require('../ejecutor/inicio_ejec.php');

?>