<?php

/**

 */

require('../encarte/encarte_vista_adm.php');

?>