<?php

/**

 */

require('manEntfinanciera.php');

?>