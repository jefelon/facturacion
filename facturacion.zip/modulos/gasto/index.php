<?php

/**

 */

require('gasto_vista.php');

?>